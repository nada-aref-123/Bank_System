﻿
namespace bank_sys
{
    partial class add_bank
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Applybtn3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.BC = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.Label();
            this.BA = new System.Windows.Forms.TextBox();
            this.lname = new System.Windows.Forms.Label();
            this.BN = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.EXIT = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.boxx = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.boxx)).BeginInit();
            this.SuspendLayout();
            // 
            // Applybtn3
            // 
            this.Applybtn3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Applybtn3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Applybtn3.FlatAppearance.BorderSize = 0;
            this.Applybtn3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Applybtn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Applybtn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Applybtn3.ForeColor = System.Drawing.Color.White;
            this.Applybtn3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Applybtn3.Location = new System.Drawing.Point(149, 375);
            this.Applybtn3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Applybtn3.Name = "Applybtn3";
            this.Applybtn3.Size = new System.Drawing.Size(429, 52);
            this.Applybtn3.TabIndex = 42;
            this.Applybtn3.Text = "Apply";
            this.Applybtn3.UseVisualStyleBackColor = false;
            this.Applybtn3.Click += new System.EventHandler(this.Applybtn3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F);
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(380, 268);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 23);
            this.label1.TabIndex = 41;
            this.label1.Text = "Bank Code";
            // 
            // BC
            // 
            this.BC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BC.Font = new System.Drawing.Font("Arial", 13.2F);
            this.BC.Location = new System.Drawing.Point(384, 297);
            this.BC.Margin = new System.Windows.Forms.Padding(4);
            this.BC.Name = "BC";
            this.BC.Size = new System.Drawing.Size(242, 26);
            this.BC.TabIndex = 40;
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Font = new System.Drawing.Font("Arial", 12F);
            this.address.ForeColor = System.Drawing.Color.DarkBlue;
            this.address.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.address.Location = new System.Drawing.Point(123, 190);
            this.address.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(72, 23);
            this.address.TabIndex = 39;
            this.address.Text = "Adress";
            // 
            // BA
            // 
            this.BA.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BA.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BA.Location = new System.Drawing.Point(127, 221);
            this.BA.Margin = new System.Windows.Forms.Padding(4);
            this.BA.Multiline = true;
            this.BA.Name = "BA";
            this.BA.Size = new System.Drawing.Size(242, 104);
            this.BA.TabIndex = 38;
            // 
            // lname
            // 
            this.lname.AutoSize = true;
            this.lname.Font = new System.Drawing.Font("Arial", 12F);
            this.lname.ForeColor = System.Drawing.Color.DarkBlue;
            this.lname.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lname.Location = new System.Drawing.Point(380, 192);
            this.lname.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.lname.Name = "lname";
            this.lname.Size = new System.Drawing.Size(111, 23);
            this.lname.TabIndex = 37;
            this.lname.Text = "Bank Name";
            // 
            // BN
            // 
            this.BN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BN.Font = new System.Drawing.Font("Arial", 13.2F);
            this.BN.Location = new System.Drawing.Point(384, 221);
            this.BN.Margin = new System.Windows.Forms.Padding(4);
            this.BN.Name = "BN";
            this.BN.Size = new System.Drawing.Size(242, 26);
            this.BN.TabIndex = 36;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkBlue;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(267, 13);
            this.label3.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(200, 32);
            this.label3.TabIndex = 35;
            this.label3.Text = "Add New Bank\r\n";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(25)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(100, 531);
            this.panel1.TabIndex = 34;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::bank_sys.Properties.Resources.setting;
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(21, 26);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(53, 51);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::bank_sys.Properties.Resources.bank_icon;
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(324, 65);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(63, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 43;
            this.pictureBox2.TabStop = false;
            // 
            // EXIT
            // 
            this.EXIT.Image = global::bank_sys.Properties.Resources.exit1;
            this.EXIT.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.EXIT.Location = new System.Drawing.Point(656, 0);
            this.EXIT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EXIT.Name = "EXIT";
            this.EXIT.Size = new System.Drawing.Size(24, 26);
            this.EXIT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.EXIT.TabIndex = 44;
            this.EXIT.TabStop = false;
            this.EXIT.Click += new System.EventHandler(this.EXIT_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkBlue;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(111, 6);
            this.label9.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 19);
            this.label9.TabIndex = 65;
            this.label9.Text = "Setting";
            // 
            // boxx
            // 
            this.boxx.BackColor = System.Drawing.SystemColors.MenuBar;
            this.boxx.Image = global::bank_sys.Properties.Resources.ddd;
            this.boxx.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.boxx.Location = new System.Drawing.Point(115, 31);
            this.boxx.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.boxx.Name = "boxx";
            this.boxx.Size = new System.Drawing.Size(44, 46);
            this.boxx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.boxx.TabIndex = 64;
            this.boxx.TabStop = false;
            this.boxx.Click += new System.EventHandler(this.boxx_Click);
            // 
            // add_bank
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuBar;
            this.ClientSize = new System.Drawing.Size(678, 531);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.boxx);
            this.Controls.Add(this.EXIT);
            this.Controls.Add(this.Applybtn3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BC);
            this.Controls.Add(this.address);
            this.Controls.Add(this.BA);
            this.Controls.Add(this.lname);
            this.Controls.Add(this.BN);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "add_bank";
            this.Text = "add_bank";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.boxx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Applybtn3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox BC;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.TextBox BA;
        private System.Windows.Forms.Label lname;
        private System.Windows.Forms.TextBox BN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox EXIT;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox boxx;
    }
}