﻿
namespace bank_sys
{
    partial class add_emp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.EXIT = new System.Windows.Forms.PictureBox();
            this.birth = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Gender = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Frist = new System.Windows.Forms.TextBox();
            this.Pho = new System.Windows.Forms.Label();
            this.salary = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.Label();
            this.Addr = new System.Windows.Forms.TextBox();
            this.lname = new System.Windows.Forms.Label();
            this.Last = new System.Windows.Forms.TextBox();
            this.Submitbtn5 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.EMPDGV = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.boxx = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EMPDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.boxx)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(25)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(100, 760);
            this.panel1.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::bank_sys.Properties.Resources.acc1;
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(27, 13);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 61);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkBlue;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(400, 11);
            this.label3.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(259, 32);
            this.label3.TabIndex = 26;
            this.label3.Text = "Add New Employee";
            // 
            // EXIT
            // 
            this.EXIT.Image = global::bank_sys.Properties.Resources.exit1;
            this.EXIT.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.EXIT.Location = new System.Drawing.Point(982, 0);
            this.EXIT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EXIT.Name = "EXIT";
            this.EXIT.Size = new System.Drawing.Size(24, 26);
            this.EXIT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.EXIT.TabIndex = 27;
            this.EXIT.TabStop = false;
            this.EXIT.Click += new System.EventHandler(this.EXIT_Click);
            // 
            // birth
            // 
            this.birth.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.birth.Font = new System.Drawing.Font("Arial", 13.2F);
            this.birth.Location = new System.Drawing.Point(749, 348);
            this.birth.Margin = new System.Windows.Forms.Padding(4);
            this.birth.Name = "birth";
            this.birth.Size = new System.Drawing.Size(242, 26);
            this.birth.TabIndex = 73;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label1.Font = new System.Drawing.Font("Arial", 12F);
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(745, 313);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 23);
            this.label1.TabIndex = 72;
            this.label1.Text = "Birthdate";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label6.Font = new System.Drawing.Font("Arial", 12F);
            this.label6.ForeColor = System.Drawing.Color.DarkBlue;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(751, 237);
            this.label6.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 23);
            this.label6.TabIndex = 71;
            this.label6.Text = "Sex";
            // 
            // Gender
            // 
            this.Gender.Font = new System.Drawing.Font("Arial", 12F);
            this.Gender.FormattingEnabled = true;
            this.Gender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.Gender.Location = new System.Drawing.Point(749, 265);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(242, 31);
            this.Gender.TabIndex = 70;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(224, 103);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 17);
            this.label7.TabIndex = 69;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F);
            this.label5.ForeColor = System.Drawing.Color.DarkBlue;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(451, 313);
            this.label5.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 23);
            this.label5.TabIndex = 68;
            this.label5.Text = "Branch ID";
            // 
            // bid
            // 
            this.bid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bid.Font = new System.Drawing.Font("Arial", 13.2F);
            this.bid.Location = new System.Drawing.Point(455, 342);
            this.bid.Margin = new System.Windows.Forms.Padding(4);
            this.bid.Name = "bid";
            this.bid.Size = new System.Drawing.Size(242, 26);
            this.bid.TabIndex = 67;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F);
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(745, 168);
            this.label2.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 23);
            this.label2.TabIndex = 66;
            this.label2.Text = "Employee ID";
            // 
            // id
            // 
            this.id.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.id.Font = new System.Drawing.Font("Arial", 13.2F);
            this.id.Location = new System.Drawing.Point(749, 197);
            this.id.Margin = new System.Windows.Forms.Padding(4);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(242, 26);
            this.id.TabIndex = 65;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F);
            this.label4.ForeColor = System.Drawing.Color.DarkBlue;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(163, 168);
            this.label4.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 23);
            this.label4.TabIndex = 64;
            this.label4.Text = "Frist Name";
            // 
            // Frist
            // 
            this.Frist.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Frist.Font = new System.Drawing.Font("Arial", 13.2F);
            this.Frist.Location = new System.Drawing.Point(167, 197);
            this.Frist.Margin = new System.Windows.Forms.Padding(4);
            this.Frist.Name = "Frist";
            this.Frist.Size = new System.Drawing.Size(242, 26);
            this.Frist.TabIndex = 63;
            // 
            // Pho
            // 
            this.Pho.AutoSize = true;
            this.Pho.Font = new System.Drawing.Font("Arial", 12F);
            this.Pho.ForeColor = System.Drawing.Color.DarkBlue;
            this.Pho.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Pho.Location = new System.Drawing.Point(451, 252);
            this.Pho.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.Pho.Name = "Pho";
            this.Pho.Size = new System.Drawing.Size(63, 23);
            this.Pho.TabIndex = 62;
            this.Pho.Text = "salary";
            // 
            // salary
            // 
            this.salary.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.salary.Font = new System.Drawing.Font("Arial", 13.2F);
            this.salary.Location = new System.Drawing.Point(455, 281);
            this.salary.Margin = new System.Windows.Forms.Padding(4);
            this.salary.Name = "salary";
            this.salary.Size = new System.Drawing.Size(242, 26);
            this.salary.TabIndex = 61;
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Font = new System.Drawing.Font("Arial", 12F);
            this.address.ForeColor = System.Drawing.Color.DarkBlue;
            this.address.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.address.Location = new System.Drawing.Point(168, 239);
            this.address.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(72, 23);
            this.address.TabIndex = 60;
            this.address.Text = "Adress";
            // 
            // Addr
            // 
            this.Addr.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Addr.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addr.Location = new System.Drawing.Point(172, 270);
            this.Addr.Margin = new System.Windows.Forms.Padding(4);
            this.Addr.Multiline = true;
            this.Addr.Name = "Addr";
            this.Addr.Size = new System.Drawing.Size(242, 104);
            this.Addr.TabIndex = 59;
            // 
            // lname
            // 
            this.lname.AutoSize = true;
            this.lname.Font = new System.Drawing.Font("Arial", 12F);
            this.lname.ForeColor = System.Drawing.Color.DarkBlue;
            this.lname.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lname.Location = new System.Drawing.Point(451, 168);
            this.lname.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.lname.Name = "lname";
            this.lname.Size = new System.Drawing.Size(105, 23);
            this.lname.TabIndex = 58;
            this.lname.Text = "Last Name";
            // 
            // Last
            // 
            this.Last.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Last.Font = new System.Drawing.Font("Arial", 13.2F);
            this.Last.Location = new System.Drawing.Point(455, 197);
            this.Last.Margin = new System.Windows.Forms.Padding(4);
            this.Last.Name = "Last";
            this.Last.Size = new System.Drawing.Size(242, 26);
            this.Last.TabIndex = 57;
            // 
            // Submitbtn5
            // 
            this.Submitbtn5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Submitbtn5.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Submitbtn5.FlatAppearance.BorderSize = 0;
            this.Submitbtn5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Submitbtn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Submitbtn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Submitbtn5.ForeColor = System.Drawing.Color.White;
            this.Submitbtn5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Submitbtn5.Location = new System.Drawing.Point(350, 418);
            this.Submitbtn5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Submitbtn5.Name = "Submitbtn5";
            this.Submitbtn5.Size = new System.Drawing.Size(385, 49);
            this.Submitbtn5.TabIndex = 74;
            this.Submitbtn5.Text = "Submit";
            this.Submitbtn5.UseVisualStyleBackColor = false;
            this.Submitbtn5.Click += new System.EventHandler(this.Submitbtn5_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::bank_sys.Properties.Resources.bank_icon;
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(494, 65);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(54, 55);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 75;
            this.pictureBox2.TabStop = false;
            // 
            // EMPDGV
            // 
            this.EMPDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EMPDGV.Location = new System.Drawing.Point(97, 513);
            this.EMPDGV.Name = "EMPDGV";
            this.EMPDGV.RowHeadersWidth = 51;
            this.EMPDGV.RowTemplate.Height = 24;
            this.EMPDGV.Size = new System.Drawing.Size(914, 247);
            this.EMPDGV.TabIndex = 76;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkBlue;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(112, 3);
            this.label9.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 19);
            this.label9.TabIndex = 78;
            this.label9.Text = "Setting";
            // 
            // boxx
            // 
            this.boxx.BackColor = System.Drawing.SystemColors.MenuBar;
            this.boxx.Image = global::bank_sys.Properties.Resources.ddd;
            this.boxx.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.boxx.Location = new System.Drawing.Point(116, 28);
            this.boxx.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.boxx.Name = "boxx";
            this.boxx.Size = new System.Drawing.Size(44, 46);
            this.boxx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.boxx.TabIndex = 77;
            this.boxx.TabStop = false;
            this.boxx.Click += new System.EventHandler(this.boxx_Click);
            // 
            // add_emp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuBar;
            this.ClientSize = new System.Drawing.Size(1007, 760);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.boxx);
            this.Controls.Add(this.EMPDGV);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Submitbtn5);
            this.Controls.Add(this.birth);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.id);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Frist);
            this.Controls.Add(this.Pho);
            this.Controls.Add(this.salary);
            this.Controls.Add(this.address);
            this.Controls.Add(this.Addr);
            this.Controls.Add(this.lname);
            this.Controls.Add(this.Last);
            this.Controls.Add(this.EXIT);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "add_emp";
            this.Text = "add_emp";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EMPDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.boxx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox EXIT;
        private System.Windows.Forms.TextBox birth;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox Gender;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox bid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox id;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Frist;
        private System.Windows.Forms.Label Pho;
        private System.Windows.Forms.TextBox salary;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.TextBox Addr;
        private System.Windows.Forms.Label lname;
        private System.Windows.Forms.TextBox Last;
        private System.Windows.Forms.Button Submitbtn5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView EMPDGV;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox boxx;
    }
}