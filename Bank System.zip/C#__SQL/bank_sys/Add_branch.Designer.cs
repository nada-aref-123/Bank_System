﻿
namespace bank_sys
{
    partial class Add_branch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lname = new System.Windows.Forms.Label();
            this.b_id = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.Label();
            this.BAddres = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Bcode = new System.Windows.Forms.TextBox();
            this.Applybtn = new System.Windows.Forms.Button();
            this.EXIT = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.boxx = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.boxx)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(25)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(100, 517);
            this.panel1.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::bank_sys.Properties.Resources.setting;
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(21, 13);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(63, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkBlue;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(253, 13);
            this.label3.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(225, 32);
            this.label3.TabIndex = 24;
            this.label3.Text = "Add New Branch";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // lname
            // 
            this.lname.AutoSize = true;
            this.lname.Font = new System.Drawing.Font("Arial", 12F);
            this.lname.ForeColor = System.Drawing.Color.DarkBlue;
            this.lname.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lname.Location = new System.Drawing.Point(381, 187);
            this.lname.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.lname.Name = "lname";
            this.lname.Size = new System.Drawing.Size(97, 23);
            this.lname.TabIndex = 28;
            this.lname.Text = "Branch ID";
            // 
            // b_id
            // 
            this.b_id.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.b_id.Font = new System.Drawing.Font("Arial", 13.2F);
            this.b_id.Location = new System.Drawing.Point(385, 216);
            this.b_id.Margin = new System.Windows.Forms.Padding(4);
            this.b_id.Name = "b_id";
            this.b_id.Size = new System.Drawing.Size(242, 26);
            this.b_id.TabIndex = 27;
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Font = new System.Drawing.Font("Arial", 12F);
            this.address.ForeColor = System.Drawing.Color.DarkBlue;
            this.address.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.address.Location = new System.Drawing.Point(124, 185);
            this.address.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(72, 23);
            this.address.TabIndex = 30;
            this.address.Text = "Adress";
            // 
            // BAddres
            // 
            this.BAddres.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BAddres.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BAddres.Location = new System.Drawing.Point(128, 216);
            this.BAddres.Margin = new System.Windows.Forms.Padding(4);
            this.BAddres.Multiline = true;
            this.BAddres.Name = "BAddres";
            this.BAddres.Size = new System.Drawing.Size(242, 104);
            this.BAddres.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F);
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(381, 263);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 23);
            this.label1.TabIndex = 32;
            this.label1.Text = "Bank Code";
            // 
            // Bcode
            // 
            this.Bcode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Bcode.Font = new System.Drawing.Font("Arial", 13.2F);
            this.Bcode.Location = new System.Drawing.Point(385, 292);
            this.Bcode.Margin = new System.Windows.Forms.Padding(4);
            this.Bcode.Name = "Bcode";
            this.Bcode.Size = new System.Drawing.Size(242, 26);
            this.Bcode.TabIndex = 31;
            // 
            // Applybtn
            // 
            this.Applybtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Applybtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Applybtn.FlatAppearance.BorderSize = 0;
            this.Applybtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Applybtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Applybtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Applybtn.ForeColor = System.Drawing.Color.White;
            this.Applybtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Applybtn.Location = new System.Drawing.Point(150, 370);
            this.Applybtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Applybtn.Name = "Applybtn";
            this.Applybtn.Size = new System.Drawing.Size(429, 52);
            this.Applybtn.TabIndex = 33;
            this.Applybtn.Text = "Apply";
            this.Applybtn.UseVisualStyleBackColor = false;
            this.Applybtn.Click += new System.EventHandler(this.Applybtn_Click);
            // 
            // EXIT
            // 
            this.EXIT.Image = global::bank_sys.Properties.Resources.exit1;
            this.EXIT.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.EXIT.Location = new System.Drawing.Point(613, 13);
            this.EXIT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EXIT.Name = "EXIT";
            this.EXIT.Size = new System.Drawing.Size(24, 26);
            this.EXIT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.EXIT.TabIndex = 14;
            this.EXIT.TabStop = false;
            this.EXIT.Click += new System.EventHandler(this.EXIT_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::bank_sys.Properties.Resources.bank_icon;
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(326, 65);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(63, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 44;
            this.pictureBox2.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkBlue;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(111, 4);
            this.label9.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 19);
            this.label9.TabIndex = 67;
            this.label9.Text = "Setting";
            // 
            // boxx
            // 
            this.boxx.BackColor = System.Drawing.SystemColors.MenuBar;
            this.boxx.Image = global::bank_sys.Properties.Resources.ddd;
            this.boxx.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.boxx.Location = new System.Drawing.Point(115, 29);
            this.boxx.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.boxx.Name = "boxx";
            this.boxx.Size = new System.Drawing.Size(44, 46);
            this.boxx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.boxx.TabIndex = 66;
            this.boxx.TabStop = false;
            this.boxx.Click += new System.EventHandler(this.boxx_Click);
            // 
            // Add_branch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuBar;
            this.ClientSize = new System.Drawing.Size(641, 517);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.boxx);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Applybtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Bcode);
            this.Controls.Add(this.address);
            this.Controls.Add(this.BAddres);
            this.Controls.Add(this.lname);
            this.Controls.Add(this.b_id);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.EXIT);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Add_branch";
            this.Text = "Add_branch";
            this.Load += new System.EventHandler(this.Add_branch_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.boxx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox EXIT;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lname;
        private System.Windows.Forms.TextBox b_id;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.TextBox BAddres;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Bcode;
        private System.Windows.Forms.Button Applybtn;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox boxx;
    }
}