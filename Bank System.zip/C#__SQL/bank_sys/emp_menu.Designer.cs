﻿
namespace bank_sys
{
    partial class emp_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.box5 = new System.Windows.Forms.PictureBox();
            this.box4 = new System.Windows.Forms.PictureBox();
            this.box3 = new System.Windows.Forms.PictureBox();
            this.EXIT = new System.Windows.Forms.PictureBox();
            this.box1 = new System.Windows.Forms.PictureBox();
            this.box2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.box5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(25)))));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.box5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.box4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.box3);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.EXIT);
            this.panel1.Controls.Add(this.box1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.box2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(506, 503);
            this.panel1.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(58, 285);
            this.label6.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 27);
            this.label6.TabIndex = 67;
            this.label6.Text = "Manage Loans";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(275, 219);
            this.label4.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(195, 27);
            this.label4.TabIndex = 65;
            this.label4.Text = "Display Loan List";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(41, 146);
            this.label5.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(212, 23);
            this.label5.TabIndex = 63;
            this.label5.Text = "Display Customers List";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(305, 354);
            this.label3.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 27);
            this.label3.TabIndex = 61;
            this.label3.Text = "Add Account";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(306, 92);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 23);
            this.label1.TabIndex = 59;
            this.label1.Text = "Add Customer";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(151, 11);
            this.label2.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 33);
            this.label2.TabIndex = 3;
            this.label2.Text = "Main Menu";
            // 
            // box5
            // 
            this.box5.BackColor = System.Drawing.Color.White;
            this.box5.Image = global::bank_sys.Properties.Resources.images__2_;
            this.box5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.box5.Location = new System.Drawing.Point(103, 329);
            this.box5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.box5.Name = "box5";
            this.box5.Size = new System.Drawing.Size(76, 68);
            this.box5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.box5.TabIndex = 66;
            this.box5.TabStop = false;
            this.box5.Click += new System.EventHandler(this.box5_Click);
            // 
            // box4
            // 
            this.box4.BackColor = System.Drawing.SystemColors.Window;
            this.box4.Image = global::bank_sys.Properties.Resources.LLLLLLOAN;
            this.box4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.box4.Location = new System.Drawing.Point(340, 252);
            this.box4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.box4.Name = "box4";
            this.box4.Size = new System.Drawing.Size(76, 71);
            this.box4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.box4.TabIndex = 64;
            this.box4.TabStop = false;
            this.box4.Click += new System.EventHandler(this.box4_Click);
            // 
            // box3
            // 
            this.box3.BackColor = System.Drawing.SystemColors.Window;
            this.box3.Image = global::bank_sys.Properties.Resources.dis11;
            this.box3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.box3.Location = new System.Drawing.Point(103, 175);
            this.box3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.box3.Name = "box3";
            this.box3.Size = new System.Drawing.Size(76, 71);
            this.box3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.box3.TabIndex = 62;
            this.box3.TabStop = false;
            this.box3.Click += new System.EventHandler(this.box3_Click);
            // 
            // EXIT
            // 
            this.EXIT.Image = global::bank_sys.Properties.Resources.exit1;
            this.EXIT.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.EXIT.Location = new System.Drawing.Point(479, 4);
            this.EXIT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EXIT.Name = "EXIT";
            this.EXIT.Size = new System.Drawing.Size(24, 26);
            this.EXIT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.EXIT.TabIndex = 16;
            this.EXIT.TabStop = false;
            this.EXIT.Click += new System.EventHandler(this.EXIT_Click);
            // 
            // box1
            // 
            this.box1.BackColor = System.Drawing.Color.White;
            this.box1.Image = global::bank_sys.Properties.Resources.acc11;
            this.box1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.box1.Location = new System.Drawing.Point(340, 387);
            this.box1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.box1.Name = "box1";
            this.box1.Size = new System.Drawing.Size(76, 68);
            this.box1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.box1.TabIndex = 60;
            this.box1.TabStop = false;
            this.box1.Click += new System.EventHandler(this.box1_Click);
            // 
            // box2
            // 
            this.box2.BackColor = System.Drawing.SystemColors.Window;
            this.box2.Image = global::bank_sys.Properties.Resources.cust;
            this.box2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.box2.Location = new System.Drawing.Point(337, 121);
            this.box2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.box2.Name = "box2";
            this.box2.Size = new System.Drawing.Size(76, 71);
            this.box2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.box2.TabIndex = 58;
            this.box2.TabStop = false;
            this.box2.Click += new System.EventHandler(this.box2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::bank_sys.Properties.Resources.images__3_;
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(3, 4);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(30, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 68;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // emp_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 503);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "emp_menu";
            this.Text = "emp_menu";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.box5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox box1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox box2;
        private System.Windows.Forms.PictureBox EXIT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox box4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox box3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox box5;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}