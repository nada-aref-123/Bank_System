﻿
namespace bank_sys
{
    partial class add_acc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ACB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ACNUM = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ssn = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ACTYP = new System.Windows.Forms.TextBox();
            this.Submitbtn1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.EXIT = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.ACCDGV = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.boxx = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ACCDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.boxx)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(25)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(100, 629);
            this.panel1.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::bank_sys.Properties.Resources.acc1;
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(27, 13);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 61);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F);
            this.label5.ForeColor = System.Drawing.Color.DarkBlue;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(115, 217);
            this.label5.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 23);
            this.label5.TabIndex = 50;
            this.label5.Text = "Account Balance";
            // 
            // ACB
            // 
            this.ACB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ACB.Font = new System.Drawing.Font("Arial", 13.2F);
            this.ACB.Location = new System.Drawing.Point(119, 246);
            this.ACB.Margin = new System.Windows.Forms.Padding(4);
            this.ACB.Name = "ACB";
            this.ACB.Size = new System.Drawing.Size(242, 26);
            this.ACB.TabIndex = 49;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F);
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(427, 136);
            this.label2.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 23);
            this.label2.TabIndex = 48;
            this.label2.Text = "Account Number";
            // 
            // ACNUM
            // 
            this.ACNUM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ACNUM.Font = new System.Drawing.Font("Arial", 13.2F);
            this.ACNUM.Location = new System.Drawing.Point(431, 165);
            this.ACNUM.Margin = new System.Windows.Forms.Padding(4);
            this.ACNUM.Name = "ACNUM";
            this.ACNUM.Size = new System.Drawing.Size(242, 26);
            this.ACNUM.TabIndex = 47;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F);
            this.label4.ForeColor = System.Drawing.Color.DarkBlue;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(115, 136);
            this.label4.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 23);
            this.label4.TabIndex = 46;
            this.label4.Text = "SSN";
            // 
            // ssn
            // 
            this.ssn.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ssn.Font = new System.Drawing.Font("Arial", 13.2F);
            this.ssn.Location = new System.Drawing.Point(119, 165);
            this.ssn.Margin = new System.Windows.Forms.Padding(4);
            this.ssn.Name = "ssn";
            this.ssn.Size = new System.Drawing.Size(242, 26);
            this.ssn.TabIndex = 45;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F);
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(688, 185);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 23);
            this.label1.TabIndex = 54;
            this.label1.Text = "Branch ID";
            // 
            // BID
            // 
            this.BID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BID.Font = new System.Drawing.Font("Arial", 13.2F);
            this.BID.Location = new System.Drawing.Point(692, 214);
            this.BID.Margin = new System.Windows.Forms.Padding(4);
            this.BID.Name = "BID";
            this.BID.Size = new System.Drawing.Size(133, 26);
            this.BID.TabIndex = 53;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F);
            this.label3.ForeColor = System.Drawing.Color.DarkBlue;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(427, 217);
            this.label3.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 23);
            this.label3.TabIndex = 52;
            this.label3.Text = "Account Type";
            // 
            // ACTYP
            // 
            this.ACTYP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ACTYP.Font = new System.Drawing.Font("Arial", 13.2F);
            this.ACTYP.Location = new System.Drawing.Point(431, 246);
            this.ACTYP.Margin = new System.Windows.Forms.Padding(4);
            this.ACTYP.Name = "ACTYP";
            this.ACTYP.Size = new System.Drawing.Size(242, 26);
            this.ACTYP.TabIndex = 51;
            // 
            // Submitbtn1
            // 
            this.Submitbtn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Submitbtn1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Submitbtn1.FlatAppearance.BorderSize = 0;
            this.Submitbtn1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Submitbtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Submitbtn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Submitbtn1.ForeColor = System.Drawing.Color.White;
            this.Submitbtn1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Submitbtn1.Location = new System.Drawing.Point(302, 319);
            this.Submitbtn1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Submitbtn1.Name = "Submitbtn1";
            this.Submitbtn1.Size = new System.Drawing.Size(326, 49);
            this.Submitbtn1.TabIndex = 55;
            this.Submitbtn1.Text = "Submit";
            this.Submitbtn1.UseVisualStyleBackColor = false;
            this.Submitbtn1.Click += new System.EventHandler(this.Submitbtn1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkBlue;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(324, 0);
            this.label6.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(236, 32);
            this.label6.TabIndex = 56;
            this.label6.Text = "Add New Account";
            // 
            // EXIT
            // 
            this.EXIT.BackColor = System.Drawing.Color.White;
            this.EXIT.Image = global::bank_sys.Properties.Resources.exit1;
            this.EXIT.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.EXIT.Location = new System.Drawing.Point(811, 0);
            this.EXIT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EXIT.Name = "EXIT";
            this.EXIT.Size = new System.Drawing.Size(24, 26);
            this.EXIT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.EXIT.TabIndex = 57;
            this.EXIT.TabStop = false;
            this.EXIT.Click += new System.EventHandler(this.EXIT_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::bank_sys.Properties.Resources.bank_icon;
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(413, 48);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(54, 55);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 58;
            this.pictureBox2.TabStop = false;
            // 
            // ACCDGV
            // 
            this.ACCDGV.BackgroundColor = System.Drawing.Color.Silver;
            this.ACCDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ACCDGV.Location = new System.Drawing.Point(99, 404);
            this.ACCDGV.Name = "ACCDGV";
            this.ACCDGV.RowHeadersWidth = 51;
            this.ACCDGV.RowTemplate.Height = 24;
            this.ACCDGV.Size = new System.Drawing.Size(736, 233);
            this.ACCDGV.TabIndex = 59;
            this.ACCDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ACCDGV_CellContentClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkBlue;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(116, 3);
            this.label9.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 19);
            this.label9.TabIndex = 63;
            this.label9.Text = "Setting";
            // 
            // boxx
            // 
            this.boxx.BackColor = System.Drawing.SystemColors.MenuBar;
            this.boxx.Image = global::bank_sys.Properties.Resources.ddd;
            this.boxx.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.boxx.Location = new System.Drawing.Point(120, 28);
            this.boxx.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.boxx.Name = "boxx";
            this.boxx.Size = new System.Drawing.Size(44, 46);
            this.boxx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.boxx.TabIndex = 62;
            this.boxx.TabStop = false;
            this.boxx.Click += new System.EventHandler(this.boxx_Click);
            // 
            // add_acc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(833, 629);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.boxx);
            this.Controls.Add(this.ACCDGV);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.EXIT);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Submitbtn1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ACTYP);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ACB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ACNUM);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ssn);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "add_acc";
            this.Text = "add_acc";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ACCDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.boxx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ACB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ACNUM;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ssn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox BID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ACTYP;
        private System.Windows.Forms.Button Submitbtn1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox EXIT;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView ACCDGV;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox boxx;
    }
}