﻿
namespace bank_sys
{
    partial class new_signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.EMP_ID = new System.Windows.Forms.TextBox();
            this.Submitbtn7 = new System.Windows.Forms.Button();
            this.EXIT = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.boxx = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.boxx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(25)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(100, 450);
            this.panel1.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::bank_sys.Properties.Resources.acc1;
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(27, 13);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 61);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkBlue;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(222, 13);
            this.label6.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(325, 32);
            this.label6.TabIndex = 57;
            this.label6.Text = "Add New User to sign up";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F);
            this.label5.ForeColor = System.Drawing.Color.DarkBlue;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(127, 220);
            this.label5.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 23);
            this.label5.TabIndex = 61;
            this.label5.Text = "Password";
            // 
            // password
            // 
            this.password.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.password.Font = new System.Drawing.Font("Arial", 13.2F);
            this.password.Location = new System.Drawing.Point(131, 249);
            this.password.Margin = new System.Windows.Forms.Padding(4);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(242, 26);
            this.password.TabIndex = 60;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F);
            this.label4.ForeColor = System.Drawing.Color.DarkBlue;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(127, 148);
            this.label4.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 23);
            this.label4.TabIndex = 59;
            this.label4.Text = "UserName";
            // 
            // username
            // 
            this.username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.username.Font = new System.Drawing.Font("Arial", 13.2F);
            this.username.Location = new System.Drawing.Point(131, 177);
            this.username.Margin = new System.Windows.Forms.Padding(4);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(242, 26);
            this.username.TabIndex = 58;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F);
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(409, 190);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 23);
            this.label1.TabIndex = 63;
            this.label1.Text = "Employee ID";
            // 
            // EMP_ID
            // 
            this.EMP_ID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EMP_ID.Font = new System.Drawing.Font("Arial", 13.2F);
            this.EMP_ID.Location = new System.Drawing.Point(413, 219);
            this.EMP_ID.Margin = new System.Windows.Forms.Padding(4);
            this.EMP_ID.Name = "EMP_ID";
            this.EMP_ID.Size = new System.Drawing.Size(242, 26);
            this.EMP_ID.TabIndex = 62;
            // 
            // Submitbtn7
            // 
            this.Submitbtn7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Submitbtn7.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Submitbtn7.FlatAppearance.BorderSize = 0;
            this.Submitbtn7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Submitbtn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Submitbtn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Submitbtn7.ForeColor = System.Drawing.Color.White;
            this.Submitbtn7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Submitbtn7.Location = new System.Drawing.Point(221, 318);
            this.Submitbtn7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Submitbtn7.Name = "Submitbtn7";
            this.Submitbtn7.Size = new System.Drawing.Size(326, 49);
            this.Submitbtn7.TabIndex = 64;
            this.Submitbtn7.Text = "Submit";
            this.Submitbtn7.UseVisualStyleBackColor = false;
            this.Submitbtn7.Click += new System.EventHandler(this.Submitbtn7_Click);
            // 
            // EXIT
            // 
            this.EXIT.BackColor = System.Drawing.Color.White;
            this.EXIT.Image = global::bank_sys.Properties.Resources.exit1;
            this.EXIT.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.EXIT.Location = new System.Drawing.Point(681, 0);
            this.EXIT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EXIT.Name = "EXIT";
            this.EXIT.Size = new System.Drawing.Size(24, 26);
            this.EXIT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.EXIT.TabIndex = 65;
            this.EXIT.TabStop = false;
            this.EXIT.Click += new System.EventHandler(this.EXIT_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkBlue;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(102, 3);
            this.label9.Margin = new System.Windows.Forms.Padding(7, 2, 3, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 19);
            this.label9.TabIndex = 67;
            this.label9.Text = "Setting";
            // 
            // boxx
            // 
            this.boxx.BackColor = System.Drawing.SystemColors.MenuBar;
            this.boxx.Image = global::bank_sys.Properties.Resources.ddd;
            this.boxx.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.boxx.Location = new System.Drawing.Point(117, 28);
            this.boxx.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.boxx.Name = "boxx";
            this.boxx.Size = new System.Drawing.Size(44, 46);
            this.boxx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.boxx.TabIndex = 66;
            this.boxx.TabStop = false;
            this.boxx.Click += new System.EventHandler(this.boxx_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::bank_sys.Properties.Resources.bank_icon;
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(342, 60);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(67, 70);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 68;
            this.pictureBox2.TabStop = false;
            // 
            // new_signup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuBar;
            this.ClientSize = new System.Drawing.Size(705, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.boxx);
            this.Controls.Add(this.EXIT);
            this.Controls.Add(this.Submitbtn7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.EMP_ID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.password);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.username);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "new_signup";
            this.Text = "new_signup";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.boxx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox EMP_ID;
        private System.Windows.Forms.Button Submitbtn7;
        private System.Windows.Forms.PictureBox EXIT;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox boxx;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}